"""PAGE 4 — PREDIKSI & REKOMENDASI KARIR (Top-N)"""
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from utils.data_loader import (load_data, build_profiles,
                                top_items, career_top_skills)
from utils.functions import CSS, P, BASE, score_all

st.set_page_config(page_title="Prediksi", page_icon="🎯", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)

df       = load_data()
profiles = build_profiles(df)
all_sk   = sorted({s for L in df["skills_list"] for s in L})
all_tl   = sorted({t for L in df["tools_list"]  for t in L})
all_db   = sorted({d for L in df["db_list"]      for d in L})

MEDALS = ["🥇","🥈","🥉"]
PRESETS = {
    "— Tidak pakai preset —": {},
    "Mahasiswa Web Dev (Python + JS + React)": {
        "sk":["python","javascript","html/css","react","node.js","typescript"],
        "tl":["visual studio code"],"db":["postgresql","mongodb"],"yr":2,"edu":2.0},
    "Mahasiswa Data Science (Python + SQL)": {
        "sk":["python","sql","pandas","numpy","scikit-learn","matplotlib"],
        "tl":["jupyter notebook/jupyterlab","visual studio code"],
        "db":["postgresql","mysql"],"yr":2,"edu":2.0},
    "Mahasiswa ML / AI (Deep Learning)": {
        "sk":["python","tensorflow","pytorch","scikit-learn","sql","docker"],
        "tl":["jupyter notebook/jupyterlab","visual studio code"],
        "db":["postgresql"],"yr":3,"edu":2.0},
    "Mahasiswa Mobile (Android + iOS)": {
        "sk":["java","kotlin","swift","flutter","dart"],
        "tl":["android studio","xcode"],"db":["sqlite","firebase"],"yr":2,"edu":2.0},
    "Mahasiswa DevOps/Cloud": {
        "sk":["python","bash/shell (all shells)","docker","kubernetes",
              "amazon web services (aws)","terraform"],
        "tl":["visual studio code","vim"],"db":["postgresql","redis"],"yr":3,"edu":2.0},
    "Mahasiswa Cybersecurity": {
        "sk":["python","bash/shell (all shells)","powershell","c","c++",
              "sql","typescript"],
        "tl":["visual studio code","vim"],"db":["postgresql","mysql"],"yr":3,"edu":2.0},
}

st.markdown('<div class="sec-hd">🎯 Prediksi & Rekomendasi Karir</div>',
            unsafe_allow_html=True)
st.caption("Masukkan profil Anda → dapatkan rekomendasi Top-N career path berdasarkan "
           "kecocokan skill, tools, database, pengalaman, dan pendidikan.")

# ─── PRESET ───────────────────────────────────────────────────────────────────
preset_name = st.selectbox("💡 Mulai dari preset", list(PRESETS.keys()))
init = PRESETS.get(preset_name, {})

# ─── INPUT FORM ───────────────────────────────────────────────────────────────
st.markdown('<div class="sec-hd">1️⃣  Profil Anda</div>', unsafe_allow_html=True)
col1, col2 = st.columns(2)

with col1:
    user_sk = st.multiselect(
        "💻 Skills (bahasa, framework, platform)",
        all_sk,
        default=[s for s in init.get("sk",[]) if s in all_sk],
        help="Pilih SEMUA yang sudah Anda pelajari/gunakan.",
    )
    user_tl = st.multiselect(
        "🛠️ Tools / IDE",
        all_tl,
        default=[t for t in init.get("tl",[]) if t in all_tl],
    )

with col2:
    user_db = st.multiselect(
        "🗄️ Database",
        all_db,
        default=[d for d in init.get("db",[]) if d in all_db],
    )
    user_yr = st.slider("⏱️ Pengalaman coding (tahun)", 0, 50,
                        int(init.get("yr", 2)))
    user_edu = st.selectbox(
        "🎓 Pendidikan terakhir",
        [0.0, 1.0, 2.0, 3.0, 4.0, 6.0],
        format_func=lambda x: {
            0.0:"None/Self-taught", 1.0:"High School",
            2.0:"Bachelor", 3.0:"Master", 4.0:"PhD", 6.0:"Bootcamp/Other",
        }[x],
        index=2,
    )

# Bobot advanced
with st.expander("⚙️ Atur Bobot Scoring (advanced)"):
    bc = st.columns(5)
    ws = bc[0].slider("Skills",     0.0,1.0,0.55,0.05)
    wt = bc[1].slider("Tools",      0.0,1.0,0.20,0.05)
    wd = bc[2].slider("Databases",  0.0,1.0,0.10,0.05)
    wy = bc[3].slider("Pengalaman", 0.0,1.0,0.10,0.05)
    we = bc[4].slider("Pendidikan", 0.0,1.0,0.05,0.05)
    tot = ws+wt+wd+wy+we
    if tot > 0:
        ws,wt,wd,wy,we = ws/tot, wt/tot, wd/tot, wy/tot, we/tot
    st.caption(f"Bobot ternormalisasi: Skill={ws:.0%} | Tool={wt:.0%} | "
               f"DB={wd:.0%} | Exp={wy:.0%} | Edu={we:.0%}")

# ─── GENERATE ─────────────────────────────────────────────────────────────────
st.markdown('<div class="sec-hd">2️⃣  Hasil Rekomendasi</div>', unsafe_allow_html=True)

if st.button("🚀 Generate Rekomendasi Top-N", type="primary", use_container_width=True):
    if not user_sk and not user_tl and not user_db:
        st.error("Pilih minimal 1 skill / tool / database.")
    else:
        res = score_all(user_sk, user_tl, user_db, user_yr, user_edu,
                        profiles, (ws,wt,wd,wy,we))

        # ── TOP 3 HERO CARDS ──
        st.markdown("### 🏆 Top 3 Rekomendasi")
        top3 = res.head(3).reset_index(drop=True)
        hcols = st.columns(3)
        for i, hc in enumerate(hcols):
            r = top3.iloc[i]
            bg = [
                "linear-gradient(135deg,#1D9E75,#5DCAA5)",
                "linear-gradient(135deg,#2E86AB,#0A9396)",
                "linear-gradient(135deg,#F18F01,#EE9B00)",
            ][i]
            hc.markdown(f"""
            <div style="background:{bg};padding:1.6rem 1rem;border-radius:14px;
                        color:white;text-align:center;box-shadow:0 4px 16px rgba(0,0,0,.12);">
              <div style="font-size:2.2rem;">{MEDALS[i]}</div>
              <h3 style="color:white;margin:.3rem 0;font-size:1.1rem;">{r['career']}</h3>
              <div style="font-size:2.8rem;font-weight:800;line-height:1;">
                {r['total']:.1f}
              </div>
              <div style="font-size:.8rem;opacity:.9;">match score / 100</div>
            </div>""", unsafe_allow_html=True)

        st.write("")

        # ── BAR CHART TOP 10 ──
        top10 = res.head(10)
        fig = px.bar(top10, x="total", y="career", orientation="h",
                     text="total", color="total", color_continuous_scale="Greens")
        fig.update_traces(texttemplate="%{text:.1f}", textposition="outside",
                          cliponaxis=False)
        fig.update_layout(**BASE, title="Match Score — Top 10 Career Path",
                          xaxis_title="Score", yaxis_title="",
                          yaxis={"categoryorder":"total ascending"},
                          coloraxis_showscale=False, height=450)
        st.plotly_chart(fig, use_container_width=True)

        # ── BREAKDOWN SKOR WINNER ──
        winner = res.iloc[0]
        st.markdown(f"### 🔍 Breakdown Skor — {winner['career']}")

        bk_df = pd.DataFrame({
            "Komponen": ["Skills","Tools","Databases","Pengalaman","Pendidikan"],
            "Skor Mentah": [winner["skill"],winner["tool"],winner["db"],
                            winner["exp"],winner["edu"]],
            "Bobot (%)": [ws*100,wt*100,wd*100,wy*100,we*100],
        })
        bk_df["Kontribusi"] = (bk_df["Skor Mentah"] * bk_df["Bobot (%)"]/100).round(2)

        bl, br = st.columns([1.4,1])
        with bl:
            fig = go.Figure()
            fig.add_trace(go.Bar(name="Skor Mentah",
                                 x=bk_df["Komponen"], y=bk_df["Skor Mentah"],
                                 marker_color="#5DCAA5",
                                 text=bk_df["Skor Mentah"].round(1),
                                 textposition="outside"))
            fig.add_trace(go.Bar(name="Kontribusi ke Total",
                                 x=bk_df["Komponen"], y=bk_df["Kontribusi"],
                                 marker_color="#1D9E75",
                                 text=bk_df["Kontribusi"].round(1),
                                 textposition="outside"))
            fig.update_layout(**BASE, barmode="group", height=380,
                              yaxis_title="Score",
                              legend=dict(orientation="h",y=1.12))
            st.plotly_chart(fig, use_container_width=True)
        with br:
            st.dataframe(bk_df.style.format({
                "Skor Mentah":"{:.1f}","Bobot (%)":"{:.1f}%","Kontribusi":"{:.2f}"
            }), hide_index=True, use_container_width=True)

            # Gauge total
            fig = go.Figure(go.Indicator(
                mode="gauge+number+delta",
                value=winner["total"],
                title={"text":f"Match Score\n{winner['career']}","font":{"size":13}},
                delta={"reference":50,"increasing":{"color":"#1D9E75"},
                       "decreasing":{"color":"#C73E1D"}},
                gauge={
                    "axis":{"range":[0,100]},
                    "bar":{"color":"#1D9E75"},
                    "steps":[
                        {"range":[0,30],"color":"#FDECEA"},
                        {"range":[30,60],"color":"#FFF3E0"},
                        {"range":[60,100],"color":"#E8F5EF"},
                    ],
                }
            ))
            fig.update_layout(**BASE, height=280)
            st.plotly_chart(fig, use_container_width=True)

        # ── SKILL GAPS ──
        winner_prof = profiles[winner["career"]]
        user_set = set(user_sk)
        sorted_sk = sorted(winner_prof["skills"].items(), key=lambda x:-x[1])
        gaps = [(s,p) for s,p in sorted_sk[:30] if s not in user_set][:10]

        if gaps:
            st.markdown(f"### 📚 Skill Gap — Yang Perlu Dipelajari untuk {winner['career']}")
            gap_df = pd.DataFrame(gaps, columns=["Skill","Prevalence di Career"])
            gap_df["% Developer yang Pakai"] = (gap_df["Prevalence di Career"]*100).round(1)
            gap_df.drop("Prevalence di Career", axis=1, inplace=True)
            gap_df["Prioritas"] = ["🔴 Tinggi" if i<3 else "🟡 Sedang" if i<6 else "🟢 Opsional"
                                   for i in range(len(gap_df))]

            cl, cr = st.columns([1.4,1])
            with cl:
                fig = px.bar(gap_df, x="% Developer yang Pakai", y="Skill",
                             orientation="h", text="% Developer yang Pakai",
                             color="% Developer yang Pakai",
                             color_continuous_scale="Reds")
                fig.update_traces(texttemplate="%{text:.0f}%", textposition="outside",
                                  cliponaxis=False)
                fig.update_layout(**BASE, title="Skill yang Belum Dikuasai",
                                  yaxis={"categoryorder":"total ascending"},
                                  coloraxis_showscale=False, xaxis_title="%",
                                  height=380)
                st.plotly_chart(fig, use_container_width=True)
            with cr:
                st.dataframe(gap_df, hide_index=True, use_container_width=True)

        # ── RADAR PERBANDINGAN POSISI USER ──
        st.markdown("### 📡 Posisi Anda vs Top Career")
        from utils.data_loader import career_stats
        from utils.functions import radar_career
        top5_cars = res.head(5)["career"].tolist()
        fig = radar_career(df, top5_cars)
        st.plotly_chart(fig, use_container_width=True)

        # ── FULL TABLE ──
        with st.expander("📋 Lihat semua 18 career + skor lengkap"):
            res_disp = res.copy()
            for c in ["total","skill","tool","db","exp","edu"]:
                res_disp[c] = res_disp[c].round(2)
            res_disp.columns = ["Career","Total","Skill","Tool",
                                 "DB","Pengalaman","Pendidikan"]
            st.dataframe(res_disp, hide_index=True, use_container_width=True)

        st.markdown(
            '<div class="ins info">ℹ️ Sistem ini menggunakan <b>rule-based weighted '
            'scoring</b> berbasis profil probabilistik tiap career. '
            'Bobot default: Skill 55% (paling diskriminatif berdasarkan EDA — '
            'korelasi exp↔skill hanya r=0.008), Tool 20%, DB 10%, '
            'Pengalaman 10%, Pendidikan 5%.</div>', unsafe_allow_html=True)

# ─── METODOLOGI ───────────────────────────────────────────────────────────────
st.divider()
with st.expander("ℹ️ Metodologi Lengkap Sistem Rekomendasi"):
    st.markdown("""
    **Pendekatan:** Rule-based Weighted Scoring berbasis profil probabilistik career path.

    **Formula:**
    ```
    skill_score  = mean( P(skill ∈ career) for skill in user_skills ) × 100
    tool_score   = mean( P(tool  ∈ career) for tool  in user_tools  ) × 100
    db_score     = mean( P(db    ∈ career) for db    in user_dbs    ) × 100
    exp_score    = max(0, 100 − |user_years − median_years_career|/30 × 100)
    edu_score    = max(0, 100 − |user_edu   − median_edu_career|   / 6 × 100)

    TOTAL = w_sk·skill + w_tl·tool + w_db·db + w_yr·exp + w_edu·edu
    ```

    **Dasar penentuan bobot:**
    - Skills (55%): korelasi tertinggi dengan career identity; r(exp,skill)=0.008 → skill lebih diskriminatif dari pengalaman
    - Tools (20%): signature tool membedakan antar career (contoh: Android Studio = Mobile Dev)
    - Databases (10%): relevant tapi lebih generic
    - Pengalaman (10%): seniority signal, bukan skill proxy
    - Pendidikan (5%): 84% bachelor di semua career → low discriminative power

    **Upgrade ke Deep Learning:**
    Modul scoring ini bisa diganti model Multi-input MLP:
    - Input: one-hot skills + one-hot tools + one-hot db + years + edu (1-hot)
    - Hidden: Dense(512, ReLU) → Dropout(0.3) → Dense(256, ReLU) → Dense(128, ReLU)
    - Output: Dense(18, Softmax) → Top-N argmax
    - Dataset: 139,079 baris yang sudah balanced ini siap langsung untuk training
    """)
